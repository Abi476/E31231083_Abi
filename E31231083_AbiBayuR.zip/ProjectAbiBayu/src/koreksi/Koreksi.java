
/**
 *
 * @author abiba
 */
package Koreksi ;
public class Koreksi {
    //proram tidak dapat berjalan karena perbedaan nama package dengan nama testing//

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("What's wrong with this program?");
    }
    
}
